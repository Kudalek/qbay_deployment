var ExternalDashboardConfig = {
    redirectUrl: 'https://fctgausyd.qbay.wns.com/Dashboard/default'
};